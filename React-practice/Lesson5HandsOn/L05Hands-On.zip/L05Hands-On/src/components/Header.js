import React from 'react';


const Header = ({ title }) => (
    <div>
        <a href="/">Home</a>
        <a href="/About">About</a>
        <a href="/FavoriteThings">FavoriteThings</a>
    </div>
);

export default Header;